import axios from "axios";


// export const getDomains = async (url: string) => {
//     try {
//       const response = await axios.get(`${url}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getDomainsOne = async (url: string, id: string | number) => {
//     try {
//       const response = await axios.get(`${url}/${id}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getFields = async (url: string) => {
//     try {
//       const response = await axios.get(`${url}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getFieldsOne = async (url: string, id: string | number) => {
//     try {
//       const response = await axios.get(`${url}/${id}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getMainSpecialties = async (url: string) => {
//   try {
//     const response = await axios.get(`${url}`);
//     return response.data;
//   } catch (error) {
//     return error;
//   }
// }

// export const getMainSpecialtyOne = async (url: string, id: string | number) => {
//   try {
//     const response = await axios.get(`${url}/${id}`);
//     return response.data;
//   } catch (error) {
//     return error;
//   }
// }

// export const getSpecialties = async (url: string, page: string | null) => {
//   try {
//     let response: any = ""
//     if (page) { response = await axios.get(`${url}?page=${page}`); }
//     else { response = await axios.get(`${url}`); }
    
//     return response.data;
//   } catch (error) {
//     return error;
//   }
// }

// export const getSpecialtyOne = async (url: string, id: string | number) => {
//   try {
//     const response = await axios.get(`${url}/${id}`);
//     return response.data;
//   } catch (error) {
//     return error;
//   }
// }

// export const getCourses = async (url: string) => {
//     try {
//       const response = await axios.get(`${url}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getCourseOne = async (url: string, id: string | number) => {
//     try {
//       const response = await axios.get(`${url}/${id}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getLevels = async (url: string) => {
//     try {
//       const response = await axios.get(`${url}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

// export const getLevelOne = async (url: string, id: string | number) => {
//     try {
//       const response = await axios.get(`${url}/${id}`);
//       return response.data;
//     } catch (error) {
//       return error;
//     }
// }

export const GET_CUSTOMUSER_QUERY = `
  query MyQuery {
    allUsers {
      id
    }
  }
`;

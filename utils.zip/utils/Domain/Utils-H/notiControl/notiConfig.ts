import { RootApi } from "@/config";

export const NotificationUrl = RootApi + "/higher/higher_noti_control/notification"
export const ComplainUrl = RootApi + "/higher/higher_noti_control/complain"
export const GetNotificationUrl = RootApi + "/higher/higher_noti_control/get-notification"
export const GetComplainUrl = RootApi + "/higher/higher_noti_control/get-complain"

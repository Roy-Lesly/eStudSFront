
export type GetDataConfig = {
  cache: string;
  next: {
    revalidate: number
  };
  // Can Add More Configs
};
  
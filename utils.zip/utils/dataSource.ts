export const Subdomains = [
    { id: 1, subdomain: "brains" },
    { id: 2, subdomain: "kings" },
    { id: 3, subdomain: "joan" },
    { id: 4, subdomain: "john" },
    { id: 5, subdomain: "clings" },
    { id: 6, subdomain: "essm" },
    { id: 7, subdomain: "test" },
    { id: 8, subdomain: "austin" },
    { id: 9, subdomain: "bhip" },
    { id: 10, subdomain: "lucbel" },
    { id: 11, subdomain: "patrick" },
    { id: 12, subdomain: "testsec" },
]


export const HelpNumber = [
    "693358642",
    // "693358642" 
]


export const CAMark = [
    19.9, 
    // 14.9
]


export const LandingPageTitle = [
    19.9,
    // 14.9
]



export const CYCLE_CHOICES = [
    { name: "FIRST", value: "FIRST" },
    { name: "SECOND", value: "SECOND" },
]

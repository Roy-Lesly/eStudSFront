import Loader from '@/section-h/common/Loader'
import React from 'react'

const loading = () => {
  return (
    <Loader />
  )
}

export default loading
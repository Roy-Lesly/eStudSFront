import NotLoggedIn from '@/section-h/common/NotLoggedIn'
import React from 'react'

const page = () => {
  return (
    <NotLoggedIn />
  )
}

export default page
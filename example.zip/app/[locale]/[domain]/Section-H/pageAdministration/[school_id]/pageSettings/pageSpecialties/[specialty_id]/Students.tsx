'use client';

import React from 'react';
import { EdgeSchoolFees } from '@/Domain/schemas/interfaceGraphql';
import { TableColumn } from '@/Domain/schemas/interfaceGraphqlSecondary';
import MyTableComp from '@/components/Table/MyTableComp';
import { FaRightLong } from 'react-icons/fa6';
import { useRouter } from 'next/navigation';
import { JwtPayload } from '@/serverActions/interfaces';
import { jwtDecode } from 'jwt-decode';

const Students = ({ data, p }: { data: EdgeSchoolFees[], p: any }) => {

  const token = localStorage.getItem("token");
  const user: JwtPayload | null = token ? jwtDecode(token) : null;
  const router = useRouter();
  const Columns: TableColumn<EdgeSchoolFees>[] = [
    { header: "#", align: "center", render: (_item: EdgeSchoolFees, index: number) => index + 1, },
    { header: "Matricle", accessor: "node.userprofile.customuser.matricle", align: "left" },
    { header: "Full Name", accessor: "node.userprofile.customuser.fullName", align: "left" },
    {
      header: "Print", hideColumn: user?.is_superuser ? false : !user?.page.map((p: string) => p.toUpperCase()).includes("DOCUMENT"), align: "center", render: (item: EdgeSchoolFees, index: number) => <button
        onClick={() => router.push(`/${p.domain}/Section-H/pageAdministration/${p.school_id}/pageResult/pageTranscript/${item.node.id}/1`)}
        className="bg-green-200 p-1 rounded-full"
      >
        <FaRightLong color="green" size={21} />
      </button>,
    },
  ];


  return (
    <div>
      <div>
        <MyTableComp
          data={data}
          columns={Columns}
        />
      </div>
    </div>
  );
};

export default Students;

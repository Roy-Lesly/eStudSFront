import ComingSoon from '@/ComingSoon'
import React from 'react'

const page = () => {
  return (
    <div>
      <ComingSoon />
    </div>
  )
}

export default page

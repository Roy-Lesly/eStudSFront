import React from 'react'

const UpdateResult = () => {
  return (
    <div>
      UpdateResult
    </div>
  )
}

export default UpdateResult

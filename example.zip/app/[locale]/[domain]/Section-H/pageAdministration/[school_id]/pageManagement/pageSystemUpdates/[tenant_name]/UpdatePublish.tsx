import React from 'react'

const UpdatePublish = () => {
  return (
    <div>
      Publish
    </div>
  )
}

export default UpdatePublish

// app/[locale]/[domain]/Section-H/pageAdministration/[school_id]/dashboard/page.tsx

export default function Fallback() {
  return <div>Fallback dashboard page</div>;
}

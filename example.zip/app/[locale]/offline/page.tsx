'use client'
import React from 'react'

const page = () => {
  return (
    <div>
      <div className='bg-slate-100 flex font-semibold h-screen items-center justify-center rounded text-red text-xl tracking-widest'>You are offline</div>
      <div className='bg-slate-100 flex font-semibold h-screen items-center justify-center rounded text-red text-xl tracking-widest'>You are offline</div>
    </div>
  )
}

export default page